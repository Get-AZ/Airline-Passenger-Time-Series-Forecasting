# Technical Report — Airline Passenger Time Series Forecasting

## Objective
Forecast monthly airline passenger counts using time-series models while avoiding temporal leakage in parameter selection.

## Data and approach
The 144-observation historical airline dataset spans 1949–1960. Preprocessing includes a monthly datetime index, data checks, plots, stationarity testing, differencing and decomposition. Original ARIMA and SARIMA specifications were compared with seasonal naïve forecasting.

## Validation design
Expanding-window 12-month forecasts for 1956–1959 were used for tuning 16 SARIMA configurations; the final 1960 holdout was not included in the tuning loop. The final model was fitted to all observations for the 1961 forecast.

## Model results
Tuned SARIMA(0,1,0)(1,1,0,12): rolling mean MAE 20.554, RMSE 23.073, MAPE 5.149%; 1960 holdout MAE 16.600, RMSE 21.479, MAPE 3.751%. Seasonal naïve 1960 RMSE 50.708; original ARIMA RMSE 55.223; original SARIMA RMSE 21.621. Errors MAE/RMSE are in thousands of passengers.

## Diagnostics and limitations
Tuned SARIMA residual Ljung–Box p-values: lag 12 = 0.054666, lag 24 = 0.026491. Remaining residual dependence at lag 24 indicates incomplete model adequacy, despite strong holdout performance. Original SARIMA had p-values 0.3881 and 0.3384 respectively. The 1960 period had been inspected in earlier iterations; claims of a fully blind holdout should be avoided. AIC across differently initialized models is not necessarily comparable. Forecast intervals depend on model assumptions.

## Forecast interpretation
The selected model forecasts July 1961 peak 647.85 thousand passengers (95% model-based interval 582.57–713.12). Future months are predictions rather than observed outcomes.

## Conclusion
The selected SARIMA achieved strong forecasting accuracy relative to simple seasonal and nonseasonal benchmarks. It is an educational forecasting candidate, not a certified production model; future work should investigate residual dependence and forecast interval calibration.
