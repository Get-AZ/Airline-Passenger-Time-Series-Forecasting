# 30 Time Series Forecasting Interview Questions and Answers

### 1. What is a time series?

**Answer:** Observations indexed in chronological order, often with dependence across time.

### 2. What is the dataset?

**Answer:** 144 monthly airline-passenger observations from January 1949 to December 1960, expressed in thousands.

### 3. What is the prediction target?

**Answer:** The monthly count of airline passengers.

### 4. What is trend?

**Answer:** A persistent long-run increase or decrease in the level of a series.

### 5. What is seasonality?

**Answer:** A recurring pattern at a fixed calendar frequency, such as a 12-month cycle.

### 6. What is a residual?

**Answer:** The observed value minus the model fitted value or prediction.

### 7. Why use a datetime index?

**Answer:** It preserves chronological ordering and enables monthly frequency-aware forecasting.

### 8. What is stationarity?

**Answer:** Broadly, stable statistical properties over time; weak stationarity requires constant mean and covariance depending only on lag.

### 9. What does the ADF test evaluate?

**Answer:** Its null hypothesis is a unit root; low p-values provide evidence against that null.

### 10. What is first differencing?

**Answer:** Subtracting the previous observation: y_t minus y_(t-1).

### 11. What is seasonal differencing?

**Answer:** Subtracting the observation one seasonal cycle earlier: y_t minus y_(t-12).

### 12. Why use a log transform?

**Answer:** It can stabilize increasing variance and convert multiplicative changes into additive ones.

### 13. Additive versus multiplicative decomposition?

**Answer:** Additive components sum; multiplicative components multiply, appropriate when seasonal amplitude scales with level.

### 14. What is ARIMA(p,d,q)?

**Answer:** A model combining autoregression p, differencing d, and moving-average errors q.

### 15. What does SARIMA add?

**Answer:** Seasonal autoregressive, differencing, and moving-average terms with period s.

### 16. Why is s=12?

**Answer:** The data are monthly and the seasonal cycle is annual.

### 17. What is seasonal naïve forecasting?

**Answer:** Forecast each month using the observed value from the same month of the prior year.

### 18. Why include a simple baseline?

**Answer:** To demonstrate improvement over an inexpensive, transparent forecasting rule.

### 19. Why not random train/test split?

**Answer:** It mixes future information into training and violates realistic forecasting order.

### 20. What is rolling-origin validation?

**Answer:** Repeatedly fitting on expanding historical windows and forecasting the next fixed horizon.

### 21. Which years were used for validation?

**Answer:** Four 12-month validation folds covering 1956, 1957, 1958, and 1959.

### 22. How was hyperparameter tuning performed?

**Answer:** Sixteen candidate SARIMA orders were compared by mean RMSE across pre-1960 folds.

### 23. Which model was selected?

**Answer:** SARIMA(0,1,0)(1,1,0,12).

### 24. What were the final test metrics?

**Answer:** MAE 16.600, RMSE 21.479 thousand passengers, and MAPE 3.751% for 1960.

### 25. How much did the model improve over seasonal naïve?

**Answer:** The 1960 holdout RMSE was 57.64% lower.

### 26. Why compare MAE, RMSE and MAPE?

**Answer:** MAE measures typical absolute error, RMSE penalizes large errors, and MAPE reports relative percentage error.

### 27. What does the Ljung–Box test measure?

**Answer:** Whether residual autocorrelations are jointly distinguishable from zero through a chosen lag.

### 28. What diagnostic limitation remains?

**Answer:** For the tuned model, lag-24 Ljung–Box p=0.0265 suggests residual serial dependence.

### 29. What was the peak 1961 forecast?

**Answer:** July 1961, about 647.85 thousand passengers, with model-based 95% interval 582.57–713.12 thousand.

### 30. How would you improve this project?

**Answer:** Evaluate more origins, assess prediction-interval calibration, compare ETS or transformed SARIMA, and use new truly unseen data.