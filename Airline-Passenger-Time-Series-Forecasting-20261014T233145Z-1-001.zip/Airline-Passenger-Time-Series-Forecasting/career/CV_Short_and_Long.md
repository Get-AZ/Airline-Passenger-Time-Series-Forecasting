# Short CV / resume entry

**Airline Passenger Demand Forecasting | Python, SARIMA, Time Series** — Built and validated an end-to-end monthly forecasting pipeline on 144 observations (1949–1960), using ARIMA, SARIMA, seasonal naïve benchmarking, and expanding-window cross-validation. Selected SARIMA(0,1,0)(1,1,0,12) achieved **3.751% MAPE**, **21.479 RMSE**, and **57.64% lower RMSE** than the seasonal naïve baseline on the 1960 holdout.

# Long technical CV / project portfolio entry

**Airline Passenger Demand Forecasting — Statistical Time Series Modeling and Evaluation**  
**Technology:** Python, Google Colab, pandas, NumPy, matplotlib, statsmodels, scikit-learn, GitHub.

- Processed 144 monthly observations spanning January 1949 to December 1960; standardized datetime frequency and evaluated trend, seasonality, and stationarity.
- Applied ADF testing, first and seasonal differencing, log transformations, and multiplicative decomposition to characterize time-series behavior.
- Built ARIMA(2,1,2) and SARIMA(1,1,1)(1,1,1,12) baselines, plus a 12-month seasonal naïve comparator.
- Designed expanding-window rolling-origin validation across 1956–1959, preserving chronological order and withholding 1960 from hyperparameter selection.
- Evaluated 16 SARIMA candidate configurations across four folds; selected SARIMA(0,1,0)(1,1,0,12) using mean rolling RMSE of 23.073 thousand passengers.
- Achieved 1960 holdout MAE 16.600, RMSE 21.479 (thousand passengers), and MAPE 3.751%, improving RMSE by 57.64% versus seasonal naïve.
- Generated 12-month 1961 forecasts with 95% model-based prediction intervals; July peak forecast approximately 647,850 passengers.
- Assessed residual ACF and Ljung–Box tests; explicitly reported remaining autocorrelation at lag 24 (p=0.0265), separating forecasting performance from statistical adequacy.
- Packaged a rerunnable Colab notebook, metrics, forecast tables, and documentation for technical review.

**Limitations:** Small historical sample; 1960 holdout had been inspected during early experimentation; forecast intervals are conditional on the fitted model and may not be calibrated.
