# LinkedIn-ready project entry

**Project title:** Airline Passenger Demand Forecasting | Python, ARIMA & SARIMA

**Featured/project description:** Built a reproducible airline-passenger forecasting pipeline using Python, ARIMA, SARIMA, seasonal naïve benchmarking, rolling-origin validation, and residual diagnostics. Tuned SARIMA achieved 3.751% MAPE and 21.479 RMSE on the 1960 holdout, reducing RMSE by 57.64% versus the seasonal naïve baseline. Documented residual autocorrelation at lag 24.

**Short description (under 200 characters):** Forecasted airline demand with SARIMA and rolling validation; achieved 3.751% holdout MAPE and 57.64% lower RMSE than seasonal naïve.

**LinkedIn post:**

Completed an end-to-end time series forecasting project using 12 years of monthly airline passenger data. I compared ARIMA, SARIMA, and a seasonal naïve benchmark, selected parameters through four expanding-window validation folds, and evaluated on 1960 data. The selected SARIMA(0,1,0)(1,1,0,12) achieved 3.751% MAPE and 57.64% lower RMSE than seasonal naïve. I also documented an important limitation: residual autocorrelation at lag 24. The reproducible notebook, evaluation evidence, and interview notes are available in my project repository [ADD VERIFIED REPOSITORY URL AFTER PUBLICATION]. #TimeSeries #Python #Forecasting #SARIMA #DataScience #MachineLearning

**Suggested skills:** Python, pandas, statsmodels, Time Series Analysis, Forecasting, Model Validation, Statistical Modeling.

**Publishing instructions:** LinkedIn > Profile > Add profile section > Recommended > Add projects. Paste title/description, attach the GitHub URL after publication. Optionally add a Featured link and publish the post above.
